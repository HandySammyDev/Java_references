package animals2;

public interface Flyer {

    String fly();
}
