package animals2;

public interface Swimmer {

    String swim();
    String dive();

}
