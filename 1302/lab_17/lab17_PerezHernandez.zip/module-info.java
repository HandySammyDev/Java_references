module lab17lastName {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
