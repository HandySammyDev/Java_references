package exception_examples1;

public class Example1 {

    public static void main(String[] args) {
        int x=0;
        System.out.println(inverse(x));
        System.out.println("all done");
    }

    public static double inverse(int x) {
        return 1/x;
    }
}